{
Hi there,

this code exists to fool wannabe-crackers and script kiddies. It was written
to protect some code of FriFra from the Delphi forum of www.delphipraxis.de

It is simple code to encode (obfuscate) and decode (deobfuscate) strings.
The output of the binary is a Pascal-style string that can be used in your
programs. Just reference all strings encoded with my function like this

------
var
  s:String;
begin
  s:=DeObfuscate(someliteral);
.
.
------

It's simple as I said and it won't keep anyone who is really willing to crack
your code from doing it. But it's there to slow down this process ;)

Have fun.

Assarbad AT gmx DOT info


PS: Here the relevant portions of the code:
---------------------------------------------------------------------
---------------------------------------------------------------------
---------------------------------------------------------------------
}
procedure _Obfuscate(var s: string); register;
asm
  push   eax
  push   ebx
  push   edx
  mov    eax, [eax] // dereference the pointer
  test   eax, $FFFFFFFF // if s='' then exit;
  jz     @exit
  mov    edx, [eax-4] // edx := Length(s);
  cmp    edx, 4
  jnb    @loop
(*******************************************************************
 BEGIN treatment of strings less than 4 bytes long
 *******************************************************************)
  cmp    edx, 1
  je     @Only1Byte;
  cmp    edx, 2
  je     @Only2Byte;
//@Only3Byte:
  mov    dl, BYTE ptr [eax+2]
  ror    dl, type DWORD
  mov    BYTE ptr [eax+2], dl
@Only2Byte:
  mov    dl, BYTE ptr [eax+1]
  ror    dl, type DWORD
  mov    BYTE ptr [eax+1], dl
@Only1Byte:
  mov    dl, BYTE ptr [eax]
  ror    dl, type DWORD
  mov    BYTE ptr [eax], dl
  jmp    @exit
(*******************************************************************
 END treatment of strings less than 4 bytes long
 *******************************************************************)
@loop:
  cmp    edx, type DWORD
  jb     @extra
// Here goes our "encryption"
// get from memory postion
  mov    ebx, DWORD ptr [eax+edx-type DWORD]
// rotate cl bytes to the right
  ror    ebx, type DWORD
// change byte order
  bswap  ebx
// write back
  mov    DWORD ptr [eax+edx-type DWORD], ebx
// decrease to point to the next 4 characters
  sub    edx, type DWORD
  jz     @exit
  jmp    @loop
@extra:
(*******************************************************************
 BEGIN treatment of strings with LENGTH(s) MOD 4 <> 0
 *******************************************************************)
// get the first 4 bytes of the whole thing
  mov    ebx, DWORD ptr [eax]
// change byte order
  bswap  ebx
// rotate to the left
  rol    ebx, type DWORD
// write back
  mov    DWORD ptr [eax], ebx
(*******************************************************************
 END treatment of strings with LENGTH(s) MOD 4 <> 0
 *******************************************************************)
@exit:
  pop    edx
  pop    ebx
  pop    eax
end;

function Obfuscate(s: string): string;
begin
  result := s;
  _Obfuscate(result);
end;

procedure _DeObfuscate(var s: string); register;
asm
  push   eax
  push   ebx
  push   edx
  mov    eax, [eax] // dereference the pointer
  test   eax, $FFFFFFFF // if s='' then exit;
  jz     @exit
  mov    edx, [eax-4] // edx := Length(s);
  cmp    edx, 4
  jnb    @checkforoddlength
(*******************************************************************
 BEGIN treatment of strings less than 4 bytes long
 *******************************************************************)
  cmp    edx, 1
  je     @Only1Byte;
  cmp    edx, 2
  je     @Only2Byte;
//@Only3Byte:
  mov    dl, BYTE ptr [eax+2]
  ror    dl, type DWORD
  mov    BYTE ptr [eax+2], dl
@Only2Byte:
  mov    dl, BYTE ptr [eax+1]
  ror    dl, type DWORD
  mov    BYTE ptr [eax+1], dl
@Only1Byte:
  mov    dl, BYTE ptr [eax]
  ror    dl, type DWORD
  mov    BYTE ptr [eax], dl
  jmp    @exit
(*******************************************************************
 END treatment of strings less than 4 bytes long
 *******************************************************************)
@checkforoddlength:
  mov    ebx, edx
  shr    ebx, 2 // div 4
  shl    ebx, 2 // mul 4
  xor    ebx, edx
  jz     @loop  // if remainder=0 then goto loop
(*******************************************************************
 BEGIN treatment of strings with LENGTH(s) MOD 4 <> 0
 *******************************************************************)
// get the first 4 bytes of the whole thing
  mov    ebx, DWORD ptr [eax]
// rotate to the left
  ror    ebx, type DWORD
// change byte order
  bswap  ebx
// write back
  mov    DWORD ptr [eax], ebx
(*******************************************************************
 END treatment of strings with LENGTH(s) MOD 4 <> 0
 *******************************************************************)
@loop:
  cmp    edx, 4
  jb     @exit
// Here goes our "encryption"
// get from memory postion
  mov    ebx, DWORD ptr [eax+edx-type DWORD]
// change byte order
  bswap  ebx
// rotate cl bytes to the right
  rol    ebx, type DWORD
// write back
  mov    DWORD ptr [eax+edx-type DWORD], ebx
// decrease to point to the next 4 characters
  sub    edx, type DWORD
  jmp    @loop
@exit:
  pop    edx
  pop    ebx
  pop    eax
end;

function DeObfuscate(s: string): string;
begin
  result := s;
  _DeObfuscate(result);
end;
{
---------------------------------------------------------------------
---------------------------------------------------------------------
---------------------------------------------------------------------
}
